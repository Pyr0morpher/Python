import random

filepath = "KnockKnock.txt"
inFile = open(filepath, "r")

# Write your program below
randEven = random.randint(0,10) * 2
randOdd = random.randrange(1, 20, 2)

for x in range(randOdd):
  line = inFile.readline()

print ("Knock-Knock\nWho's there?")
print(line)
print(line + "who?")
line = inFile.readline()
print(line)
