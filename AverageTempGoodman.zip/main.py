filepath = "NewYorkTemps.txt"
inFile = open(filepath, "r")

line = inFile.readline()
sum = 0
count = 0

while line:
    sum += float(line)
    line = inFile.readline()
    count += 1
avg = sum / count
print("average = " + str(avg))
inFile.close()
