filepath = "books.txt"
outFile = open(filepath, 'w')

for x in range(1):
    book = input("Enter book title: ").upper()
    authorFirst = input("Enter the authors first name: ").capitalize()
    authorLast = input("Enter the authors last name: ").capitalize()
    outFile.write(book + '\t' + authorLast + ", " + authorFirst + '\n')

outFile.close()
