'''
Corbin Goodman
Bank Program
13 Dec. 2019
'''
#reads from the "balance.txt" text file I made
filepath = "balance.txt"
inFile = open(filepath, "r")
line = inFile.readline()

#prints the welcome statement and instructions
print("Welcome to The Real Bank\nInput a positive value for a deposit")
print("Input a negative value for a withdrawal\nEnter DONE if done banking")

#initializes variables and inputs first value
transfer = (input(">"))
count = 0
withTotal = 0
depTotal = 0

#while transfer is not "DONE" change the value to a float and add or subtract from "balance.txt"
while transfer != "DONE":
  transfer = float(transfer)
  line = float(line) + transfer
#if positive add to deposit total, if negative add to withdrawl total
  if transfer > 0:
    depTotal += transfer
  else:
    withTotal += transfer
#bring the number of transactions up one and input another value
  count += 1
  transfer = (input(">"))
#prints totals
print("\nTotal Withdrawn: $" + str(abs(withTotal)))
print("Total Deposited: $" + str(depTotal))
print("Current Balance after " + str(count) + " transactions: $" + str(line))