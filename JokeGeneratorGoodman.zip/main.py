jokes_filepath = "jokes.txt"
answers_filepath = "answers.txt"

jokes = open(jokes_filepath, "r")
answers = open(answers_filepath, "r")

joke_line = jokes.readline()
answer_line = answers.readline()

jokeNum = int(input("There are 10 jokes\nWhich joke do you want to see? "))

for x in range(jokeNum - 1):
  joke_line = jokes.readline()
  answer_line = answers.readline()
print("\n" + joke_line + "\n" + answer_line)

jokes.close()
answers.close()